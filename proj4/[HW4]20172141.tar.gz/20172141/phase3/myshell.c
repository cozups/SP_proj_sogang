/* $begin shellmain */
#include "myshell.h"
#include<errno.h>
#define MAXARGS   128

/* Function prototypes */
void eval(char *cmdline);
int parseline(char *buf, char **argv);
int builtin_command(char **argv); 

int main() 
{
    char cmdline[MAXLINE]; /* Command line */

    while (1) {
	/* Read */
	printf("CSE4100-SP-P4> ");
	fgets(cmdline, MAXLINE, stdin); 
	if (feof(stdin))
	    exit(0);

	/* Evaluate */
	eval(cmdline);
    } 
}
/* $end shellmain */
  
/* $begin eval */
/* eval - Evaluate a command line */
void eval(char *cmdline) 
{
    char *argv[MAXARGS]; /* Argument list execve() */
    char buf[MAXLINE];   /* Holds modified command line */
    int bg;              /* Should the job run in bg or fg? */
    pid_t pid;           /* Process id */
    int i, j, k;
    char *pargv[MAXARGS][4];	/* array for parsing command by pipe */
    int pipecnt = 0;		/* number of pipe in command */
    int fd[2];			/* file descriptor for single pipe */
    int multi_fd[MAXARGS][2];	/* file descriptor 2D array for multiple pipe */
    int pp = 0;			/* index for multi_fd */
    j = k = 0;

    strcpy(buf, cmdline);
    bg = parseline(buf, argv);

    for(i=0;argv[i]!=NULL; i++){
	if(strcmp(argv[i], "|")!=0){	// check if command has pipe	
		pargv[j][k] = argv[i];
		k++;
	}
	else {	// if pipe found, count the number of pipe and parse command by pipe
		/*
			ex) ls -al | grep abc
			in pargv array
					  [0]   [1]
				pargv[0]  ls    -al	
				pargv[1]  grep  abc
				.
				.
		*/
		j++;
		k = 0;
		pipecnt++;
	}
    }
    /*  for debugging
    for(i=0;i<pipecnt+1;i++){
	for(j=0;j<2;j++){
		printf("%s ", pargv[i][j]);
	}
	printf("\n");
    } */
    if (argv[0] == NULL)  
	return;   /* Ignore empty lines */
    if (!builtin_command(argv)) { //exit -> exit(0), & -> ignore, other -> run
	if(pipecnt == 0){	
		// pipe doesn't exist
		if(strcmp(argv[0], "cd")==0){		// run cd command in parent process
			if(strcmp(cmdline, "cd\n") == 0){
			    // cd
			    chdir(getenv("HOME"));
		    	}
		    	else{
			    // cd path, cd ..
				chdir(argv[1]);
		    	}
		}
		else {
       		 	if((pid = fork()) == 0){
				if(execvp(argv[0], argv) < 0) {	// run command & if error occured, print error message
            				printf("%s: Command not found.\n", argv[0]);
        	    			exit(0);
       		     		}
			}
		}
		/* Parent waits for foreground job to terminate */
		if (!bg){
			if(strcmp(argv[0], "cd") == 0);
			else{
				int status;
				if(waitpid(pid, &status, 0) < 0){
					unix_error("waitfg: waitpid error.\n");
				}
			} 
		}
		else//when there is backgrount process!
		    printf("%d %s", pid, cmdline);
	}
	else{
		// pipe exists
		if(pipe(fd) < 0){
			// if pipe failed
			printf("pipe 1 error.\n");
			exit(1);
		}

		// save fd to multi_fd for using by many process
		multi_fd[0][0] = fd[0];
		multi_fd[0][1] = fd[1];
		
		if((pid = fork())<0){
			// if fork failed
			printf("fork 1 failed\n");
			exit(1);
		}
		else if(pid == 0){
			// child process with first command  (ex: ls -al for [ls -al | grep ... | ...])
			
			// manipulate fd for transferring output of this process to next process
			close(STDOUT_FILENO);
			dup2(fd[1], 1);
			close(fd[1]);
	
			if(execvp(pargv[pp][0], pargv[pp])<0){
				printf("%s: Command not found.\n", pargv[0][0]);
				exit(1);
			}
		}
		else{
			// parent process, close fd[1](no more use) & wait for child process
			close(fd[1]);
			wait(NULL);
			pp++;
		}
		
		while(pp < pipecnt){
			// next process (until process with last command)
			if(pipe(multi_fd[pp])<0){
				// if pipe failed
				printf("pipe %d error.\n", pp);
				exit(1);
			}
			if((pid = fork())<0){
				// if fork failed
				printf("fork failed.\n");
				exit(1);
			}
			else if(pid == 0){
				// child process
				
				// manipulate fd for using output of previous process and transferring output of this process to next process
				close(STDIN_FILENO);
				close(STDOUT_FILENO);
				dup2(multi_fd[pp-1][0], 0);
				dup2(multi_fd[pp][1], 1);
				close(multi_fd[pp-1][0]);
				close(multi_fd[pp][1]);
				if(execvp(pargv[pp][0], pargv[pp])<0){
					printf("%s: Command not found.\n", pargv[pp][0]);
					exit(1);
				}
			}
			else{
				// parent process, close fd[1](no more use) & wait for child process
				close(multi_fd[pp][1]);
				wait(NULL);
				pp++;
			}
		}
		
		// process for last command
		if((pid = fork()) < 0){
			// if fork failed
			printf("fork last failed\n");
			exit(1);
		}
		else if(pid == 0){
			// child process

			// manipulate fd for using output of previous process and print output of this process to STDOUT
			close(STDIN_FILENO);
			dup2(multi_fd[pp-1][0], 0);
			close(multi_fd[pp-1][1]);
			close(multi_fd[pp-1][0]);
			if(execvp(pargv[pp][0], pargv[pp])<0){
				printf("%s: Command not found.\n", pargv[1][0]);
				exit(1);
			}
		}
		else{
			// parent process, wait for child process
			wait(NULL);
		}
	}
    }
    // reset pargv array for next use
    for(i=0;i<pipecnt+1;i++){
	memset(pargv[i], 0, sizeof(char *)*4);	
    }
    return;
}

/* If first arg is a builtin command, run it and return true */
int builtin_command(char **argv) 
{
    if (!strcmp(argv[0], "exit")) /* quit command */
    {
		exit(0);
    }  
    if (!strcmp(argv[0], "&"))    /* Ignore singleton & */
	return 1;
    return 0;                     /* Not a builtin command */
}
/* $end eval */

/* $begin parseline */
/* parseline - Parse the command line and build the argv array */
int parseline(char *buf, char **argv) 
{
    char *delim;         /* Points to first space delimiter */
    int argc;            /* Number of args */
    int bg;              /* Background job? */

    buf[strlen(buf)-1] = ' ';  /* Replace trailing '\n' with space */
    while (*buf && (*buf == ' ')) /* Ignore leading spaces */
	buf++;

    /* Build the argv list */
    argc = 0;
    while ((delim = strchr(buf, ' '))) {
	argv[argc++] = buf;
	*delim = '\0';
	buf = delim + 1;
	while (*buf && (*buf == ' ')) /* Ignore spaces */
            buf++;
    }
    argv[argc] = NULL;
    
    if (argc == 0)  /* Ignore blank line */
	return 1;

    /* Should the job run in the background? */
    if ((bg = (*argv[argc-1] == '&')) != 0)
	argv[--argc] = NULL;

    return bg;
}
/* $end parseline */

