[system programming lecture]

-project 4 baseline

csapp.c
        CS:APP3e functions

myshell.c
        shellex.c 파일을 기반으로 작성한 쉘 프로그램 소스

myshell.h
	csapp.h 파일과 동일



phase1은 basic internal shell command를 실행시키는 것이 목적이다.
fork()함수를 통해 child process에서 명령어를 실행해야한다.

cd, cd .. : 
	현재의 작업 디렉토리를 바꾸는 명령어이다. 
	[cd 위치] 형식으로 커맨드를 입력하면 해당 위치로 이동한다.
	[cd ..] 형식으로 입력하면 상위 디렉토리로 이동한다.
	[cd] 를 입력하면 홈 디렉토리로 이동한다.
	명령어를 입력받고 parsing을 진행하면 argv[1]에 경로가 들어있다. 
	chdir 함수를 이용하여 작업 디렉토리 위치를 바꿀 수 있다.
	argv[1]이 NULL인 경우에는 [cd]만 입력한 것이므로getenv("HOME")을 이용하여 홈 디렉토리로 이동하게끔 구현할 수 있다.
	getenv는 환경변수를 가져오는 함수이다.

ls, mkdir, rmdir, touch, cat, echo:
	이 명령어들은 exec계열 함수를 이용하여 실행시킬 수 있다.
	execve는 /bin/ 까지 입력해야 하므로 그냥 parsing한 후 실행하였을 때 커맨드를 찾지 못하는 오류가 발생하였다.
	따라서 execvp를 이용하였다.
	커맨드를 찾지 못했을 때는 에러 메시지를 출력한다.

exit:
	builtin 명령어이므로 builin command 함수에 따로 구현되어있다.
	exit(0)을 실행하며 쉘이 종료된다.
