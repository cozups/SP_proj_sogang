[system programming lecture]

-project 4 baseline

csapp.c
        CS:APP3e functions

myshell.c
        shellex.c 파일을 기반으로 작성한 쉘 프로그램 소스



phase 2는 pipe command를 실행하기 위한 것이 목적이다.
여러 개의 프로세스들을 fork한 후 한 프로세스의 실행 결과를 다른 프로세스로 넘겨주고 실행이 다 끝나면 stdout으로 출력하여야 한다.

1. 먼저 command를 pipe를 구분으로 parsing 하여야 한다.
2. 파이프의 개수에 따라 파이프가 존재하지 않으면 phase1과 같은 기능을 수행한다.
3. 파이프가 존재하는 경우 파이프 개수+1개의 프로세스를 생성하여야 한다.
4. 파이프 개수가 몇개 존재할 지 모르므로 [첫번째 커맨드/ ...중간 커맨드들(여러개)... / 마지막 커맨드]를 위한 프로세스를 생성한다.
5. 정상적인 수행을 위해 각 파이프마다 file descriptor를 잘 조정하여야 한다. 
6. 이전 프로세스의 output을 현재 프로세스의 input으로 사용하고 현재 프로세스의 output을 다음 프로세스에 넘겨주거나 stdout으로 출력하여야 한다.
각 단계마다 소스에 주석을 달아 놓았으니 이해하는데 무리는 없을 것이라 생각한다.
